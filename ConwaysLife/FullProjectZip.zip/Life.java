import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.JButton;
import javax.swing.JFrame;

public class Life implements MouseListener, ActionListener, Runnable {
	boolean[][] cells = new boolean[10][10];
	JFrame frame = new JFrame("Life Simulation");
	LifePanel panel = new LifePanel(cells);
	Container south = new Container();
	JButton start = new JButton("start");
	JButton step = new JButton("step");
	JButton stop = new JButton("stop");
	boolean running = false;

	public Life() {
		frame.setSize(600, 600); // 600 x 600 grid
		frame.setLayout(new BorderLayout());
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // ends on closing
		frame.setVisible(true); //
		frame.add(panel, BorderLayout.CENTER);
		panel.addMouseListener(this);
		// south container
		south.setLayout(new GridLayout(1, 3));
		south.add(step);
		step.addActionListener(this);
		south.add(start);
		start.addActionListener(this);
		south.add(stop);
		stop.addActionListener(this);
		frame.add(south, BorderLayout.SOUTH);

	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new Life();

	}

	@Override
	public void mouseClicked(MouseEvent event) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mousePressed(MouseEvent event) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseReleased(MouseEvent event) { // event that fills in squares of mouse click
		// System.out.println(event.getX() + "," + event.getY()); // gives x and y of
		// click
		double width = (double) panel.getWidth() / cells[0].length;
		double height = (double) panel.getHeight() / cells.length;
		int column = Math.min(cells[0].length - 1, (int) (event.getX() / width));
		int row = Math.min(cells.length - 1, (int) (event.getY() / height));
		// System.out.println(row + "," + column);
		cells[row][column] = !cells[row][column];
		frame.repaint();

	}

	@Override
	public void mouseEntered(MouseEvent event) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseExited(MouseEvent event) {
		// TODO Auto-generated method stub

	}

	@Override
	public void actionPerformed(ActionEvent event) {
		// TODO Auto-generated method stub
		if (event.getSource().equals(step)) { //if step is clicked
			Step();

		}
		if (event.getSource().equals(start)) { //if start is clicked
			if(running == false ) {
				running = true;
				Thread t = new Thread(this);
				t.start();
			}
			
		}
		if(event.getSource().equals(stop)) { //if stop is clicked then stop
			running = false;
			
		}

	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		while(running == true) {
			Step();
			try {
				Thread.sleep(500); //slows it down
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	}

	public void Step() { // a single iteration of the life simulation
		boolean[][] nextGen = new boolean[cells.length][cells[0].length];
		for (int row = 0; row < cells.length; row++) {
			for (int column = 0; column < cells[0].length; column++) {
				int neighbors = 0;
				if (row > 0 && cells[row - 1][column] == true) { // above
					neighbors++;
				}
				if (row > 0 && column > 0 && cells[row - 1][column - 1] == true) { // top left corner
					neighbors++;
				}

				if (row > 0 && column < cells[0].length - 1 && cells[row - 1][column + 1]) { // top right corner
					neighbors++;
				}
				if (row < cells.length - 1 && cells[row + 1][column] == true) { // below
					neighbors++;
				}
				if (column > 0 && cells[row][column - 1] == true) { // left
					neighbors++;
				}
				if (column < cells[0].length - 1 && cells[row][column + 1]) { // right
					neighbors++;
				}
				if (row < cells.length - 1 && column > 0 && cells[row + 1][column - 1]) { // bottom left
					neighbors++;
				}
				if (row < cells.length - 1 && column < cells[0].length - 1 && cells[row + 1][column + 1] == true) { // bottom
																													// right
					neighbors++;
				}
				// Conway's Rules of Life
				if (cells[row][column] == true) { // alive
					if (neighbors == 2 || neighbors == 3) {
						// survive to the next round
						// System.out.println("alive");
						nextGen[row][column] = true;
					} else if (neighbors < 3) {
						// die of overcrowding
						// System.out.println("dead");
						nextGen[row][column] = false;
					} else if (neighbors < 2) {
						// die of lonliness
						// System.out.println("dead");
						nextGen[row][column] = false;

					}
				} else {
					if (neighbors == 3) {
						// becomes populated
						// System.out.println("alive");
						nextGen[row][column] = true;
					} else {
						nextGen[row][column] = false;
					}
				}
			}

		}
		cells = nextGen;
		panel.setCells(nextGen);
		frame.repaint();
	}

}
// gap between second to last and last video
//correct version
